document.addEventListener("DOMContentLoaded", function() {
  const categoryImages = [
    { name: "10 Things I Hate About You", image: "10 things.jpg", director: "Gil Junger", casts: "Heath Ledger · Patrick Verona ; Julia Stiles · Kat Stratford ; Joseph Gordon-Levitt · Cameron James ; Larisa Oleynik · Bianca Stratford ; David Krumholtz.", watchLink: "https://moviesjoy.is/movie/10-things-i-hate-about-you-18907", review: "Overall, “10 Things I Hate About You” is a charming and entertaining film that skillfully blends humor, romance, and Shakespearean elements to deliver a timeless story of love, self-discovery, and acceptance.", trailer: "https://youtu.be/uE7qjQlfoRs?si=ArENMqTXrWcc1ay7" },
    { name: "The Notebook", image: "The Notebook.jpg", director: "NICK CASSAVETES", casts: " RACHEL MCADAMS RYAN GOSLING JAMES GARNER", watchLink: "https://moviesjoy.is/movie/the-notebook-19489", review: "An epic love story centered around an elderly man who reads aloud to some woman with Alzheimer's. From the notebook, the older man's words bring to life the story to a couple of who's separated by World War II, and can be reunited, seven decades after, after they've taken different paths.", trailer: "https://youtu.be/FC6biTjEyZw?si=kyXnPIXDdRZJ0C1o" },
    { name: "Flipped", image: "Flipped.jpg", director: "Rob Renier", casts: "MADELINE CARROLL CALLAN MCAULIFFE REBECCA DE MORNAY ANTHONY EDWARDS", watchLink: "https://moviesjoy.is/movie/flipped-13712", review: "Flipped is a sweet, charming, moving, lovely, well-acted coming-of-age romantic drama comedy film. While the plot offers nothing new in particular (as with mostly all rom- com films)...the 'girl meets boy' mixed with 'the not-your-typical girl next door' story, but the storytelling is slightly different.https://youtu.be/q40GxY5n2Dg?si=kfDgtipCAEfTpBwQ", trailer: "https://youtu.be/cgv5TBbNik4?si=Jqv_R5aS2rTjZXYi" },
    { name: "Now & Ever", image: "Now & Ever.jpg", director: "Christina Kyi", casts: "Zenn Kyi, Paing Phyoe Thu, Min Nyo, Khin Thazin, Ju Jue K, Zu Zue Haney Htway, Ye Naung Cho, Kyaw Thu", watchLink: "https://www.imdb.com/title/tt26894856/?ref_=ttfc_fc_tt", review: "Thiha (Zenn Kyi) is married to Wuthmone (Paing Phyoe Thu), who because of her traumatic past is suffering from psychosis. As a passionate lover, Thiha takes care of Wuthmone with much kindness. But in the later years of their marriage Wuthmone starts to suspect Thiha might be cheating on her and witnesses that he actually is. She blames only herself and rumination worsens her condition. But could what she saw have an alternative truth? Or, has Thiha fallen out of love?", trailer: "https://youtu.be/iqKX1r-ycL4?si=ucfO-cfhkAiKxLGl" },
    { name: "On Your Wedding Day", image: "On Your Wedding Day.jpg", director: "Lee Sukgeun", casts: "PARK BO-YOUNG KIM YOUNG-KWANG", watchLink: "https://moviesjoy.is/movie/on-your-wedding-day-67120", review: "This is the story of Woo Yeon, a man who sees his only love as Seung Hee, a girl who believes in falling in love in 3 seconds. It portrays the hardships of first love, spanning 10 years as they mature from children into adults. Woo Yeon was a high school student who hated studying and spent his days getting into fights.", trailer: "https://youtu.be/QJEe_JEhvw8?si=NbIyG_BMSsJY3G3T"}
  ];

  const menuList = document.getElementById("menu-list"); // Reference to the unordered list

  // Add category images dynamically
  categoryImages.forEach((movie, index) => {
    const li = document.createElement("li");
    li.className = "product";
    li.dataset.name = movie.name;

    const img = document.createElement("img");
    img.src = movie.image;
    img.alt = movie.name;
    li.appendChild(img);

    const movieName = document.createElement("p");
    movieName.textContent = movie.name;
    movieName.classList.add("movie-info");
    li.appendChild(movieName);

    const buttonsContainer = document.createElement("div");
        buttonsContainer.classList.add("movie-buttons"); const descriptionButton = document.createElement("button");
        descriptionButton.dataset.modalTarget = "#modal";
        descriptionButton.textContent = "Description";
        buttonsContainer.appendChild(descriptionButton);

        const watchButton = document.createElement("button");
        watchButton.textContent = "Watch";
        watchButton.onclick = function() {
          window.open(movie.watchLink, '_blank');
        };
        buttonsContainer.appendChild(watchButton);

        li.appendChild(buttonsContainer);

        menuList.appendChild(li);
        // Add event listener for description button and image click
        function updateModalContent(movie) {
          const modal = document.getElementById('modal');
          const modalPoster = modal.querySelector('.ptrcls');
          const modalName = modal.querySelector('.name h1');
          const modalReview = modal.querySelector('.rv');
          const modalCast = modal.querySelector('.cast');
          const modalDirector = modal.querySelector('.director');
          const cd_watch = modal.querySelector('.cd_wt');
          const cd_trailer = modal.querySelector('.cd_tl');

          modalPoster.src = movie.image;
          modalPoster.alt = movie.name;
          modalName.textContent = movie.name;
          cd_watch.onclick = () => {
            window.open(movie.watchLink, '_blank');
          };
          cd_trailer.onclick = () => {
            window.open(movie.trailer, '_blank');
          };
          modalReview.textContent = `${ movie.review }`;
          modalCast.textContent = `${ movie.casts }`;
          modalDirector.textContent = `${ movie.director }`;
          modal.classList.add('active');
          overlay.classList.add('active');
        }

        descriptionButton.addEventListener('click', () => {
          updateModalContent(movie);
        });

        img.addEventListener('click', () => {
          updateModalContent(movie);
        });

      });

      const overlay = document.getElementById('overlay');
      const closeModalButtons = document.querySelectorAll('[data-close-button]')

      // Close modal functionality
      overlay.addEventListener('click', () => {
        const modals = document.querySelectorAll('.modal.active');
        modals.forEach(modal => {
          closeModal(modal);
        });
      });

      closeModalButtons.forEach(button => {
        button.addEventListener('click', () => {
          const modal = button.closest('.modal')
          closeModal(modal)
        })
      })
      function closeModal(modal) {
        if (modal == null) return;
        modal.classList.remove('active');
        overlay.classList.remove('active');
      }
    });